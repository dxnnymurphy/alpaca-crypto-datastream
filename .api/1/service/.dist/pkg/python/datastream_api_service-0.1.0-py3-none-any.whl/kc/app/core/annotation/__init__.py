from .logger import Logger
from .singleton import Singleton